"""markd2pdf - Convert Markdown files to beautifully styled PDFs."""

__version__ = "0.1.0"
__author__ = "Ramcharan"

from markd2pdf.cli import app

__all__ = ["app"]
